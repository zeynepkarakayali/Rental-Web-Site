﻿using aracKiralamaDeneme.Models;
using aracKiralamaDeneme.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace aracKiralamaDeneme.Services
{
    public class RentalService : IRentalService
    {
    }

}
