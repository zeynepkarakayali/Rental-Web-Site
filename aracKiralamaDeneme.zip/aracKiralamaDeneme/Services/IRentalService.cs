﻿using aracKiralamaDeneme.Models.ViewModels;

namespace aracKiralamaDeneme.Services
{
    public interface IRentalService
    {
    }
}
