﻿namespace aracKiralamaDeneme.Models
{
    public class MainInfo
    {
        public double Temp { get; set; }
    }
}
