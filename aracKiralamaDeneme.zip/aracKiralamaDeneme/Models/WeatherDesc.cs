﻿namespace aracKiralamaDeneme.Models
{
    public class WeatherDesc
    {
        public string Description { get; set; }
        public string Icon { get; set; }
    }
}
