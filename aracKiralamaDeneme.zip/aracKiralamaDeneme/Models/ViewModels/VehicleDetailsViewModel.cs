﻿namespace aracKiralamaDeneme.Models.ViewModels
{
    public class VehicleDetailsViewModel
    {
        public Vehicle Vehicle { get; set; }
        public bool CanRent { get; set; }
    }
}
